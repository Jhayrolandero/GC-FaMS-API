class Main{
    
    public static void main(String args[]){
         Queue queue = new Queue();

        queue.enqueue(5);
        queue.enqueue(15);
        queue.enqueue(25);
        queue.enqueue(35);
        
        
        
        queue.displayQueue();
        System.out.println();

        System.out.println("Front is: "+queue.front());
        System.out.println("Rear is: "+queue.rear());
        System.out.println("Size is: "+queue.size());
        
        System.out.println(queue.dequeue());
        System.out.println(queue.dequeue());
        System.out.println(queue.dequeue());
        System.out.println(queue.dequeue());
        System.out.println(queue.dequeue());

        queue.displayQueue();
        
        
   
    }
}