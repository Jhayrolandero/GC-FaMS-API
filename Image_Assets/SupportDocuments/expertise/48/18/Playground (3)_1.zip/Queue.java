import java.util.NoSuchElementException ;

class Queue{
    private Node front;
    private Node rear;
    private int size;

    public void enqueue(int data){
        Node newNode = new Node(data);
        if(isEmpty()){
            front = newNode;
            rear = newNode;
        }
        else{
            rear.next = newNode;
            rear = newNode;
        }
        size++;
    }

    public int dequeue(){
         if(isEmpty()){
            throw new NoSuchElementException ();
        }
        int result = front.data;
        front = front.next;
        size--;
        return result; 
    }

    public boolean isEmpty(){
        return size == 0;
    }

    public int front(){
        return front.data;
    }

    public int rear(){
        return rear.data;
    }

    public int size(){
        return this.size;
    }

     public void displayQueue(){
        Node current = front;
        while(current != null){
            System.out.print(current.data + " ");
            current = current.next;
        }
    }
}