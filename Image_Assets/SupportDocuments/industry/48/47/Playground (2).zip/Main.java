class Main{
    
    public static void main(String args[]){
        Stack stack = new Stack();
        stack.push(5);
        stack.push(15);
        stack.push(52);
        stack.push(51);
        stack.push(151);
        stack.push(522);
    
        stack.displayStack();
        System.out.println();
        System.out.println(stack.pop());
        System.out.println(stack.pop());
        System.out.println(stack.pop());

        stack.displayStack();
        
   
    }
}