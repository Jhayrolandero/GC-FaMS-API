import java.util.EmptyStackException;

class Stack{
    private Node top;
    private int size;

    public void push(int data){
        Node newNode = new Node(data);
        newNode.next = top;
        top = newNode;
        size++;
    }

    public int pop(){
        if(isEmpty()){
            throw new EmptyStackException();
        }
        int result = top.data;
        top = top.next;
        size--;
        return result; 
    }

    public int top(){
        if(isEmpty()){
            throw new EmptyStackException();
        }
        return top.data;
    }

    public boolean isEmpty(){
        return size == 0;
    }

    public int size(){
        return size;
    }

    public void displayStack(){
        Node current = top;
        while(current != null){
            System.out.print(current.data + " ");
            current = current.next;
        }
    }
}